﻿Controls
--------

PLayer1 
'w' for UP
's' for DOWN

Player2
'up key' for UP
'down key' for DOWN 

Press 'esc' to exit game

Dependencies
------------

- SDL2
- OpenGL 2.1+ / OpenGL ES 2+
- OpenAL
- Lua / LuaJIT / LLVM-lua
- FreeType
- ModPlug
- mpg123
- Vorbisfile
- Theora

Credits
-------
Alpha Codder